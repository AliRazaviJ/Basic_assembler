import java.util.HashMap;

public class RegisterAndMemories {
    long AC = 0;
    int E = 0;
    int flag_in = 0;
    int flag_out = 0;
    int IR = 0;


    HashMap<String, Long> memory = new HashMap<String, Long>();
    HashMap<String, Long> undirectMemory = new HashMap<>();

    public RegisterAndMemories(long AC, int e, int flag_in, int flag_out) {
        this.AC = AC;
        E = e;
        this.flag_in = flag_in;
        this.flag_out = flag_out;
        this.IR = 0;

    }
}
