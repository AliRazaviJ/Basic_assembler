//import java.util.HashMap;
//import java.util.Map;
//
//class SimpleAssembler {
//    private static Map<String, Integer> memory = new HashMap<>();
//
//    public static void main(String[] args) {
//        loadInstructions();
//
//        // Example program in assembly language
//        String[] program = {
//                "LOAD 10",
//                "STORE A",
//                "LOAD 20",
//                "ADD A",
//                "STORE B"
//        };
//
//        // Assemble and execute the program
//        for (String instruction : program) {
//            assembleAndExecute(instruction);
//        }
//
//        // Print the memory contents after program execution
//        System.out.println("Memory:");
//        for (Map.Entry<String, Integer> entry : memory.entrySet()) {
//            System.out.println(entry.getKey() + ": " + entry.getValue());
//        }
//    }
//
//    private static void loadInstructions() {
//        // Instruction set: LOAD, STORE, ADD
//        memory.put("LOAD", 0);
//        memory.put("STORE", 0);
//        memory.put("ADD", 0);
//    }
//
//    private static void assembleAndExecute(String instruction) {
//        String[] parts = instruction.split(" ");
//        String opcode = parts[0];
//        int operand = Integer.parseInt(parts[1]);
//
//        switch (opcode) {
//            case "LOAD":
//                load(operand);
//                break;
//            case "STORE":
//                store(operand);
//                break;
//            case "ADD":
//                add(operand);
//                break;
//            default:
//                System.out.println("Invalid opcode: " + opcode);
//                break;
//        }
//    }
//
//    private static void load(int value) {
//        memory.put("LOAD", value);
//    }
//
//    private static void store(int location) {
//        int value = memory.get("LOAD");
//        memory.put("STORE", value);
//        memory.put("A", value);
//    }
//
//    private static void add(int location) {
//        int value = memory.get("LOAD");
//        int sum = value + memory.get("A");
//        memory.put("LOAD", sum);
//    }
//
//}