import java.sql.SQLOutput;
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
public class Main {


    public static void main(String[] args) {

        System.out.println("---------------------------------------");
        System.out.println("---------------------------------------");
        System.out.println("---------------------------------------");

        RegisterAndMemories RM = new RegisterAndMemories(0,0,0,0);
        HashMap<String, String> operates = new HashMap<String, String>();
        operates.put("ORG", "START");
        operates.put("CLA", "7800");
        operates.put("CLE", "7400");
        operates.put("CMA", "7200");
        operates.put("CME", "7100");
        operates.put("CIR", "7080");
        operates.put("CIL", "7040");
        operates.put("INC", "7020");
        operates.put("SPA", "7010");
        operates.put("SNA", "7008");
        operates.put("SZA", "7004");
        operates.put("SZE", "7002");
        operates.put("HLT", "7001");
        operates.put("INP", "F800");
        operates.put("OUT", "F400");
        operates.put("SKI", "F200");
        operates.put("SKO", "F100");
        operates.put("ION", "F080");
        operates.put("IOF", "F040");
        //-------------------
        operates.put("AND", "0");
        operates.put("ADD", "1");
        operates.put("LDA", "2");
        operates.put("STA", "3");
        operates.put("BUN", "4");
        operates.put("BSA", "5");
        operates.put("ISZ", "6");


        //------------------------------------------------------------------------------
        List<String> lines = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("---------------------------------------");
        System.out.println("how to you want to give input to assembler?");
        System.out.println("               1-User Input                ");
        System.out.println("               2-Text File Path            ");
        System.out.print(">> ");
        String com = scanner.next();
        String[] linesArray;
        if(com.equals("1"))
        {
            System.out.println("Enter lines of text (Press Enter on an empty line to stop):");
            String m = scanner.nextLine();
            while (true) {

                String line = scanner.nextLine();

                if (line.isEmpty()) {
//                    System.out.println("line is "+line);
                    break;
                }

                lines.add(line);
            }
            // Convert the list to an array if needed
            linesArray = lines.toArray(new String[0]);
        }
        else
        {
            System.out.print("input the path of text address:");
            String address = scanner.next();
            linesArray = readLinesFromFile(address);
        }




        //-----------------------------------------------------------

        if (!(linesArray[0].startsWith("ORG"))) {
            System.out.println("Code should start with ORG !!!");
            return;
        }
        //----------------------------------------------------------
        int hlt_index = linesArray.length;

        for (int i = 0; i < linesArray.length; i++) {
            if (linesArray[i].startsWith("HLT")) {
                hlt_index = i;
                for (int j = i + 1; j < linesArray.length; j++) {
                    String[] line = linesArray[j].split(" ");
//                    System.out.println("line is " + line[0]);
                    if(line[1].equals("DEC")) {
                        RM.memory.put(line[0], Long.valueOf(line[2].trim()));
                    }
                    else if(line[1].equals("HEX"))
                    {
                        RM.undirectMemory.put(line[0], Long.valueOf(line[2].trim()));
                    }
                }
                break;
            }
        }
//        System.out.println("hlt_index = "+hlt_index);
        //----------------------------------------------------------
        PC pc = new PC();
        for (pc.i = 0; pc.i < hlt_index; pc.i++) {
            assemble(linesArray[pc.i],RM,pc);




            //Print code
            if(operates.get(linesArray[pc.i].substring(0,3)).length() < 2 )
            {
                String[] address = linesArray[pc.i].split(" ");

                //undirect address
                if(RM.undirectMemory.containsKey(address[1]))
                {
                    String HexCode = "";
                    Long m = Long.valueOf(operates.get(linesArray[pc.i].substring(0,3)));

                    HexCode = Integer.toHexString(Math.toIntExact(m + 8)).toUpperCase();
                    System.out.print(HexCode);

                    long a = RM.undirectMemory.get(address[1]);
                    while(a < 100)
                    {
                        HexCode = HexCode.concat("0");
                        a = a * 10;
                        System.out.print(0);
                    }
                    System.out.print(RM.undirectMemory.get(address[1]));
                    HexCode = HexCode.concat(String.valueOf(RM.undirectMemory.get(address[1])));
                    System.out.print("        Binary: "+hexToBinary(HexCode));
                }






                //direct address
                else {
                    String HexCode = "";
                    System.out.print(operates.get(linesArray[pc.i].substring(0,3)));
                    HexCode = operates.get(linesArray[pc.i].substring(0,3));
                    long a = RM.memory.get(address[1]);
                    while (a < 100) {
                        a = a * 10;
                        System.out.print(0);
                        HexCode = HexCode.concat("0");
                    }
                    System.out.print(RM.memory.get(address[1]));
                    HexCode = HexCode.concat(String.valueOf(RM.memory.get(address[1])));
                    System.out.print("        Binary: "+hexToBinary(HexCode));
                }

            }
            else {
                System.out.print(operates.get(linesArray[pc.i].substring(0,3)));
                if(! operates.get(linesArray[pc.i].substring(0,3)).equals("START")) {
                    System.out.print("        Binary: " + hexToBinary(operates.get(linesArray[pc.i].substring(0, 3))));
                }
            }




            System.out.println();
        }

        System.out.println("END");
//        System.out.println("AC is " + RM.AC);
    }




//***************************************************************************************************

    public static void assemble(String instruction,RegisterAndMemories RM,PC pc) {
        String[] command = instruction.split(" ");
        if(command.length == 1){
            switch (command[0]) {
                case "CLA":
                    System.out.printf("%-35s","CLEAR ACCUMULATOR: ");
                    RM.AC = 0;
                    break;
                case "CLE":
                    System.out.printf("%-35s","CLEAR LINK: ");
                    RM.E = 0;
                    break;
                // ... include all the cases

                case "ISZ":
                    System.out.printf("%-35s","INCREMENT AND SKIP IF ZERO: ");
                    break;
                case "INP":
                    System.out.printf("%-35s","INPUT OPERATION: ");
                    RM.flag_in = 0;
                    break;
                case "OUT":
                    System.out.printf("%-35s","OUTPUT OPERATION: ");
                    RM.flag_out = 0;
                    break;
                case "SKI":
                    System.out.printf("%-35s","SKIP IF INPUT STATUS IS ZERO: ");
                    if (RM.flag_in == 0) {
                        pc.i++;
                    }
                    break;
                case "SKO":
                    System.out.printf("%-35s","SKIP IF OUTPUT STATUS IS ZERO: ");
                    if (RM.flag_out == 1) {
                        pc.i++;
                    }
                    break;
                case "ION":
                    System.out.printf("%-35s","INTERRUPT ON: ");
                    break;
                case "IOF":
                    System.out.printf("%-35s","INTERRUPT OFF: ");
                    break;
                case "HLT":
                    System.out.print("HALT");
                    break;
                case "ORG":
                    break;
                case "CMA":
                    System.out.printf("%-35s","Complement Accumulator: ");
                    long temp_ac = RM.AC / 100000000;
                    RM.AC = 11111111 - temp_ac * 100000000 + 11111111 - RM.AC % 100000000;
                    break;
                case "CME":
                    System.out.printf("%-35s","Complement Link: ");
    //                int numBits = (int) (Math.log(RM.E) / Math.log(2)) + 1;
    //                // Calculate the maximum value that can be represented with the given number of bits
    //                int maxValue = (1 << numBits) - 1;
    //                // Calculate the complement by subtracting the input number from the maximum value
    //                RM.E = maxValue - RM.E;
                    RM.AC = ~RM.AC;
                    break;
                case "CIR":
                    System.out.printf("%-35s","Shift Right: ");
                    RM.AC = RM.AC >> 1;

                    break;
                case "CIL":
                    System.out.printf("%-35s","Shift Left: ");
                    RM.AC = RM.AC << 1;
                    break;
                case "INC":
                    System.out.printf("%-35s","Increment: ");
                    RM.AC++;
                    break;
                case "SPA":
                    System.out.printf("%-35s","Skip if AC is positive: ");
                    if (RM.AC > 0) {
                        pc.i++;
                    }
                    break;
                case "SNA":
                    System.out.printf("%-35s","Skip if Ac is negative: ");
                    if (RM.AC < 0) {
                        pc.i++;
                    }
                    break;
                case "SZA":
                    System.out.printf("%-35s","Skip if AC is Zero: ");
                    if (RM.AC == 0) {
                        pc.i++;
                    }
                    break;
                case "SZE":
                    System.out.printf("%-35s","Skip if E is zero: ");
                    if (RM.E == 0) {
                        pc.i++;
                    }
                    break;
                default:
                    System.out.println("INVALID INSTRUCTION");
                    break;
            }
        }
        else if(command.length == 2)
        {
            switch (command[0]) {
                case "AND":
                    System.out.printf("%-35s","AND OPERATION: ");
                    Add(command[1],RM);
                    break;
                case "ADD":
                    System.out.printf("%-35s","ADD OPERATION: ");
//                    Add(command[1],RM);
                    break;
                case "LDA":
                    System.out.printf("%-35s","LOAD ACCUMULATOR: ");
                    Lda(command[1],RM);
                    break;
                case "STA":
                    Sta(command[1],RM);
                    System.out.printf("%-35s","STORE ACCUMULATOR: ");
                    break;
                case "BUN":
                    System.out.printf("%-35s","BRANCH IF UNORDERED: ");
                    break;
                case "BSA":
                    System.out.printf("%-35s","BRANCH IF SAME: ");
                    break;
            }
        }

    }
//****************************************************************************************************

        /**
         * this function get a hexadecimal number and convert it to binary
         * @param
         * @return binary
         */
        public static String hexToBinary(String hexToBinary){
            // Convert hex string to decimal
            long decimal = Long.parseLong(hexToBinary , 16);

            // Convert decimal to binary
            String binary = Long.toBinaryString(decimal);

            // Pad leading zeros if necessary
            int padding = hexToBinary.length() * 4 - binary.length();
            if (padding > 0) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < padding; i++) {
                    sb.append('0');
                }
                sb.append(binary);
                binary = sb.toString();
            }

            return binary;
        }


    //*****************************************************************
    public static void Add(String command,RegisterAndMemories RM)
    {
        if(RM.memory.containsKey(command))
        {
            RM.AC = RM.AC + RM.memory.get(command);
        }

    }
    //*****************************************************************
    public static void And(String command,RegisterAndMemories RM)
    {
        if(RM.memory.containsKey(command))
        {
            RM.AC = RM.AC & RM.memory.get(command);
        }

    }
    //*****************************************************************
    public static void Lda(String command,RegisterAndMemories RM)
    {
        if(RM.memory.containsKey(command))
        {
            RM.AC = RM.memory.get(command);
        }

    }
    //****************************************************************
    public static void Sta(String command,RegisterAndMemories RM)
    {
        if(RM.memory.containsKey(command))
        {
            RM.memory.put(command,RM.AC);
        }

    }
    //****************************************************************
    public static void Bun(String command,RegisterAndMemories RM)
    {
        if(RM.memory.containsKey(command))
        {
            RM.AC = RM.AC + RM.memory.get(command);
        }

    }
    //***************************************************************
    public static void Bsa(String command,RegisterAndMemories RM)
    {
        if(RM.memory.containsKey(command))
        {
            RM.AC = RM.AC + RM.memory.get(command);
        }

    }
    //**************************************************************
    public static String[] readLinesFromFile(String filePath) {
        List<String> lines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lines.toArray(new String[0]);
    }

}

