public class PC {
    int i = 0;
}
